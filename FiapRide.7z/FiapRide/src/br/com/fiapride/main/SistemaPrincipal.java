package br.com.fiapride.main;

// Importamos a classe Passageiro para que o sistema a reconheça
import br.com.fiapride.model.Baleia;

public class SistemaPrincipal {

	public static void main(String[] args) {
		// Dentro do main...// Fabriquei a primeira (Instância 1)
		Baleia minhaBaleia = new Baleia();
		minhaBaleia.cor = "Azul";
		minhaBaleia.nome = "Jarvis";
		minhaBaleia.tamanhoEmMetros = 14.5;
		// Fabriquei a segunda (Instância 2)
		Baleia baleiaFavorita = new Baleia();
		baleiaFavorita.cor = "Cinza";
		baleiaFavorita.nome = "Tuluk";
		baleiaFavorita.tamanhoEmMetros = 25;
		System.out.println("Minha Baleia numero 1 é: " + "Nome:" + " " + minhaBaleia.nome + " " + "Cor:" + " "
				+ minhaBaleia.cor + " " + "Tamanho:" + " " + minhaBaleia.tamanhoEmMetros + "m");
		System.out.println("Ja a minha Baleia favorita é: " + "Nome:" + " " + baleiaFavorita.nome + " " + "Cor:" + " "
				+ baleiaFavorita.cor + " " + "Tamanho:" + " " + baleiaFavorita.tamanhoEmMetros + "m");

	}
}
