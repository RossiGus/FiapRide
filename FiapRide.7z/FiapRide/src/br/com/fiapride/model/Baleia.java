package br.com.fiapride.model;
public class Baleia { // <-- Use o nome do SEU objeto    
    // As características que você pensou    
    public String cor;
    public String nome;
    public double tamanhoEmMetros;
    
}